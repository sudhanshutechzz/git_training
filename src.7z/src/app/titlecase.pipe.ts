import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'titlecase'
})
export class TitlecasePipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    console.log("args which is array of any[]"+args);
    let first:string;
    let remi:string;
    first=value.charAt(0).toUpperCase();
    remi=value.substring(1,value.length);
    remi=remi.toLowerCase();
    return first+remi;
  }

}
