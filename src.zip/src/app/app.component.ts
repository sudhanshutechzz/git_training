import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  id;
  name;
  salary;
  department;
  public event(event)
  {alert(this.id+" "+this.name+" "+this.salary+" "+this.department);
   document.getElementById("display").innerHTML=this.id+" "+this.name+" "+this.salary+" "+this.department;
    
  }
  title = 'assignment';
  
}
