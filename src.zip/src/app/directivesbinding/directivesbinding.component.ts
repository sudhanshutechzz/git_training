import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directivesbinding',
  templateUrl: './directivesbinding.component.html',
  styleUrls: ['./directivesbinding.component.css']
})
export class DirectivesbindingComponent implements OnInit {
  id;
  index=0;
  name;
  salary;
  department;
  data:Object;
  list:Object[]=[];
  flag:boolean=false;


  
  public event(event)

  { this.data=new Object();
    this.data["id"]=this.id;
    this.data["name"]=this.name;
    this.data["salary"]=this.salary;
    this.data["dept"]=this.department;
    this.list.push(this.data);
    document.getElementById("head").style.display="block";
  document.getElementById("display1").style.display="block";
      
  }

  public event1(event)
  { 
  for(let em of this.list)
  {
    if(em["id"]==event)
    {this.id=em["id"];
    this.name=em["name"];
    this.salary= em["salary"];
    this.department=em["dept"];
    }
  }
  document.getElementById("update").style.display="block";

   console.log("done ");
  }
  public event2(event)
  { 
  for(let em of this.list)
  {
    if(em["id"]==event)
    {
      em["name"]=this.name;
      em["salary"]=this.salary;
      em["dept"]=this.department;
    }
  }
  }
  public event3(event)
  { 
  for(let em of this.list)
  {
    if(em["id"]==event)
    {
      this.list.splice(em["id"].index,1);
    }
  }
  }
  
  constructor() { }

  ngOnInit(): void {
  }

}
