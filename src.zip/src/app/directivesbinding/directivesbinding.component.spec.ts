import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DirectivesbindingComponent } from './directivesbinding.component';

describe('DirectivesbindingComponent', () => {
  let component: DirectivesbindingComponent;
  let fixture: ComponentFixture<DirectivesbindingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DirectivesbindingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DirectivesbindingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
